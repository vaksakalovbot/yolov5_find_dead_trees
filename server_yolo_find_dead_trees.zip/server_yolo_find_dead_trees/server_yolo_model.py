import os
import torch
from PIL import Image
import yaml
from flask import Flask, request, render_template, redirect, flash
from werkzeug.utils import secure_filename
import json


# папка для сохранения загруженных файлов
UPLOAD_FOLDER = 'uploads'
# расширения файлов, которые разрешено загружать
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'tif'}


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY'] = 'mySecretKeyToday'


# Функция проверки расширения файла
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def delete_files_in_folder(folder_path):
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
        except Exception as e:
            print(f'Ошибка при удалении файла {file_path}. {e}')


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route(rule='/clear_all_data')
def clear_all_data():
    path = os.getcwd() + '/'+UPLOAD_FOLDER
    delete_files_in_folder(path)
    path = os.getcwd() + '/results'
    delete_files_in_folder(path)
    path = os.getcwd() + '/static/images'
    delete_files_in_folder(path)

    flash('Все файлы с данными на сервере удалены!')
    return render_template('index.html')


@app.route(rule='/clear_results')
def clear_results():
    path = os.getcwd() + '/results'
    delete_files_in_folder(path)
    path = os.getcwd() + '/static/images'
    delete_files_in_folder(path)

    flash('Файлы с результатами обработки на сервере удалены!')
    return render_template('index.html')


@app.route(rule='/upload_files', methods=['GET', 'POST'])
def upload_files():
    if request.method == 'POST':
        # проверим, передается ли в запросе файл
        if 'files[]' not in request.files:
            flash('Не могу прочитать файл')
            return redirect(request.url)

        files = request.files.getlist('files[]')
        if len(files) == 0:
            flash('Нет выбранного файла')
            return redirect(request.url)

        for file in files:
            # Если файл не выбран, то браузер может отправить пустой файл без имени.
            if file.filename == '':
                flash('Нет выбранного файла!')
                return redirect(request.url)
            if file and allowed_file(file.filename):
                # безопасно извлекаем оригинальное имя файла
                filename = secure_filename(file.filename)
                print(filename)
                # сохраняем файл
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        flash('Файлы загружены на сервер.')
        return redirect('/')

    return render_template('upload_files.html')


@app.route(rule='/start_model')
def start_model():
    folder_path = os.getcwd() + '/'+UPLOAD_FOLDER
    image_files = os.listdir(folder_path)
    count_files = len(image_files)

    if count_files == 0:
        flash('Нет файлов для обработки. Загрузите файлы на сервер!')
        return render_template('index.html')

    result_data = {'data': [{}]}

    for i in range(0, count_files):
        result_data['data'][0][i] = {}
        result_data['data'][0][i]['image_name'] = image_files[i]
        result_data['data'][0][i]['items'] = []

        file_path = os.path.join(folder_path, image_files[i])

        im = Image.open(file_path)
        result_data['data'][0][i]['image_height'] = im.height
        result_data['data'][0][i]['image_width'] = im.width

        results = model(im, size=640)

        normal_coords = results.pandas().xyxy[0]

        labels, coord_trees = results.xyxyn[0][:, -1].cpu().numpy(), results.xyxyn[0][:, :-1].cpu().numpy()

        for index_labels, result in enumerate(labels):
            label = labels[index_labels]
            coord = coord_trees[index_labels]

            xmin, ymin, xmax, ymax = (normal_coords["xmin"][index_labels], normal_coords["ymin"][index_labels],
                                      normal_coords["xmax"][index_labels], normal_coords["ymax"][index_labels])

            xmin = int(xmin)
            ymin = int(ymin)
            xmax = int(xmax)
            ymax = int(ymax)

            width = xmax - xmin
            height = ymax - ymin

            fn = result_data["data"][0][i]["image_name"].rsplit('.', 1)[0].lower()

            save_image_path = f'./static/images/{fn}_r_{index_labels}.jpg'
            html_image_path = f'images/{fn}_r_{index_labels}.jpg'
            im.crop((xmin, ymin, xmax, ymax)).save(save_image_path)

            # print(classes[label], [xmin, ymin, width, height], coord[4])
            result_data['data'][0][i]['items'].append(
                {'name': classes[label], 'coords': [xmin, ymin, width, height],
                 'confidence': str(coord[4]), 'filename': html_image_path})

    json_object = json.dumps(result_data, indent=4)
    output_json_filename = os.getcwd() + '/results/result_data.json'
    with open(output_json_filename, "w") as outfile:
        outfile.write(json_object)

    flash('Загруженные файлы обработаны. Результаты обработки сохранены на сервере.')
    return render_template('index.html')


@app.route(rule='/show_results')
def show_results():
    input_json_filename = os.getcwd() + '/results/result_data.json'
    if not os.path.exists(input_json_filename):
        flash('Данные с результатами обработки на сервере отсутствуют!')
        return render_template('index.html')

    with open(input_json_filename, 'r') as openfile:
        result_data = json.load(openfile)

    print(type(result_data))
    print(result_data)

    return render_template(template_name_or_list='results_table.html', data=result_data)


# Сразу загрузка, обработка и вывод результата в одном месте
@app.route(rule='/find_dead_trees_online', methods=["POST"])
def find_dead_trees_online():
    if 'files[]' not in request.files:
        flash('Нет выбранного файла')
        return render_template(template_name_or_list='index.html')

    images = request.files.getlist('files[]')

    # print(images)

    result_data = {'data': [{}]}

    count_files = len(images)

    for i in range(0, count_files):
        result_data['data'][0][i] = {}
        result_data['data'][0][i]['image_name'] = images[i].filename
        result_data['data'][0][i]['items'] = []

    for index_image, image in enumerate(images):

        im = Image.open(image)
        result_data['data'][0][index_image]['image_height'] = im.height
        result_data['data'][0][index_image]['image_width'] = im.width

        results = model(im, size=640)

        normal_coords = results.pandas().xyxy[0]

        labels, coord_trees = results.xyxyn[0][:, -1].cpu().numpy(), results.xyxyn[0][:, :-1].cpu().numpy()

        for index_labels, result in enumerate(labels):
            label = labels[index_labels]
            coord = coord_trees[index_labels]

            xmin, ymin, xmax, ymax = (normal_coords["xmin"][index_labels], normal_coords["ymin"][index_labels],
                                      normal_coords["xmax"][index_labels], normal_coords["ymax"][index_labels])

            xmin = int(xmin)
            ymin = int(ymin)
            xmax = int(xmax)
            ymax = int(ymax)

            width = xmax - xmin
            height = ymax - ymin

            fn = result_data["data"][0][index_image]["image_name"].rsplit('.', 1)[0].lower()

            save_image_path = f'./static/images/{fn}_r_{index_labels}.jpg'
            html_image_path = f'images/{fn}_r_{index_labels}.jpg'
            im.crop((xmin, ymin, xmax, ymax)).save(save_image_path)

            # print(classes[label], [xmin, ymin, width, height], coord[4])
            result_data['data'][0][index_image]['items'].append(
                {'name': classes[label], 'coords': [xmin, ymin, width, height],
                 'confidence': str(coord[4]), 'filename': html_image_path})

    print(result_data)

    return render_template(template_name_or_list='results_table.html', data=result_data)


if __name__ == '__main__':
    with open('server_config.yml', 'r') as stream:
        try:
            data_yml = yaml.safe_load(stream)
            host = data_yml['host']
            port = data_yml['port']
            path_to_yolov5 = data_yml['path_to_yolov5']
            model_name = data_yml['model_name']
            classes = data_yml['classes']

        except yaml.YAMLError as exc:
            print(exc)

    print("Выбрана модель: ", model_name)

    # Загрузка предварительно обученной модели YOLOv5, работа с сетевым репозиторием
    model = torch.hub.load(repo_or_dir='ultralytics/yolov5',
                           model='custom', path=f'./models/{model_name}', force_reload=True)

    # Загрузка предварительно обученной модели YOLOv5, работа с локальным репозиторием
    # path_to_model = os.getcwd() + '/models/' + model_name
    # model = torch.hub.load(repo_or_dir=path_to_yolov5, model='custom', path=path_to_model, source='local')

    app.run(host=host, port=port, debug=False, use_reloader=False)
